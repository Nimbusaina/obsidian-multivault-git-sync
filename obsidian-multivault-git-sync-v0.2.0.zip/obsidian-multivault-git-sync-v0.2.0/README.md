# MultiVault Git Sync

Desktop-only Obsidian plugin for one Git repository containing multiple Obsidian vaults.

```text
obsidian-sync/
├── Vault-A/
├── Vault-B/
├── Vault-C/
└── .git/
```

## Added in 0.2.0

- Cross-vault lock file.
- Local-change backup before pull.
- Conflict detection after failed pull/rebase.
- Commands for conflict status, abort rebase/merge, and large-file scan.
- Large-file warning and blocking thresholds.

## Build

```bash
npm install
npm run build
```

Copy `main.js` and `manifest.json` to:

```text
YourVault/.obsidian/plugins/multivault-git-sync/
```
