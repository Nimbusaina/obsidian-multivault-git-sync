
import { App, Notice, Plugin, PluginSettingTab, Setting } from "obsidian";
import { execFile } from "child_process";
import * as fs from "fs";
import * as fsp from "fs/promises";
import * as path from "path";
import * as os from "os";

interface Settings {
  repoRoot: string;
  gitPath: string;
  autoSyncIntervalMinutes: number;
  syncOnStartup: boolean;
  commitMessagePrefix: string;
  lockStaleMinutes: number;
  showNotices: boolean;
  backupLocalChangesBeforePull: boolean;
  conflictBackupDir: string;
  warnLargeFileMB: number;
  blockLargeFileMB: number;
}

const DEFAULT_SETTINGS: Settings = {
  repoRoot: "",
  gitPath: "git",
  autoSyncIntervalMinutes: 0,
  syncOnStartup: false,
  commitMessagePrefix: "obsidian sync",
  lockStaleMinutes: 30,
  showNotices: true,
  backupLocalChangesBeforePull: true,
  conflictBackupDir: ".obsidian-git-conflicts",
  warnLargeFileMB: 50,
  blockLargeFileMB: 100
};

type GitResult = { stdout: string; stderr: string };
type FileSizeRecord = { file: string; mb: number };

export default class MultiVaultGitSyncPlugin extends Plugin {
  settings: Settings;
  private queue: Promise<void> = Promise.resolve();
  private isRunning = false;

  async onload() {
    await this.loadSettings();
    this.addSettingTab(new MultiVaultGitSyncSettingTab(this.app, this));

    this.addCommand({ id: "sync-repository-now", name: "Sync repository now", callback: () => this.enqueueSync("manual") });
    this.addCommand({ id: "show-repository-status", name: "Show repository status", callback: () => this.showStatus() });
    this.addCommand({ id: "scan-large-files", name: "Scan large files before Git commit", callback: () => this.scanLargeFilesCommand() });
    this.addCommand({ id: "show-conflict-status", name: "Show Git conflict status", callback: () => this.showConflictStatus() });
    this.addCommand({ id: "abort-rebase-or-merge", name: "Abort current Git rebase or merge", callback: () => this.abortRebaseOrMerge() });

    if (this.settings.syncOnStartup) window.setTimeout(() => this.enqueueSync("startup"), 3000);
    if (this.settings.autoSyncIntervalMinutes > 0) {
      const ms = this.settings.autoSyncIntervalMinutes * 60 * 1000;
      this.registerInterval(window.setInterval(() => this.enqueueSync("interval"), ms));
    }
  }

  async loadSettings() { this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData()); }
  async saveSettings() { await this.saveData(this.settings); }

  private notice(message: string, timeout = 5000) {
    if (this.settings.showNotices) new Notice(message, timeout);
    console.log(`[MultiVault Git Sync] ${message}`);
  }

  private enqueueSync(reason: string) {
    this.queue = this.queue.then(() => this.syncRepository(reason)).catch((error) => {
      console.error(error);
      this.notice(`Git sync failed: ${error.message ?? error}`, 12000);
    });
  }

  private async syncRepository(reason: string) {
    if (this.isRunning) { this.notice("Sync skipped: another sync is already running.", 5000); return; }
    this.isRunning = true;
    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) { this.isRunning = false; this.notice("Repository root not found. Configure it in plugin settings.", 8000); return; }
    const lockPath = path.join(repoRoot, ".git", "obsidian-multivault-sync.lock");
    let lockHandle: fs.promises.FileHandle | null = null;
    try {
      await this.ensureGitRepo(repoRoot);
      await this.cleanupStaleLock(lockPath);
      lockHandle = await this.acquireLock(lockPath, reason);
      if (!lockHandle) { this.notice("Sync skipped: another vault is syncing this repository.", 5000); return; }

      const busyState = await this.getBusyGitState(repoRoot);
      if (busyState) { this.notice(`Sync stopped: repository is already in ${busyState} state. Resolve or abort it first.`, 12000); return; }
      this.notice(`Git sync started (${reason}).`, 4000);

      let backupDir: string | null = null;
      if (this.settings.backupLocalChangesBeforePull) {
        backupDir = await this.backupLocalChanges(repoRoot);
        if (backupDir) this.notice(`Local changed files backed up: ${backupDir}`, 8000);
      }

      try { await this.git(["pull", "--rebase", "--autostash"], repoRoot); }
      catch (error: any) { await this.reportConflictAfterFailedPull(repoRoot, backupDir, error); return; }

      const conflictFiles = await this.getConflictFiles(repoRoot);
      if (conflictFiles.length > 0) { this.notice(`Sync stopped: ${conflictFiles.length} conflicted file(s). Check conflict status.`, 12000); return; }

      const large = await this.scanLargeFiles(repoRoot);
      if (large.blocked.length > 0) {
        console.warn("Blocked large files:", large.blocked);
        this.notice(`Sync stopped: ${large.blocked.length} file(s) exceed ${this.settings.blockLargeFileMB} MB. Run large-file scan for details.`, 12000);
        return;
      }
      if (large.warned.length > 0) {
        console.warn("Large file warnings:", large.warned);
        this.notice(`Warning: ${large.warned.length} file(s) exceed ${this.settings.warnLargeFileMB} MB.`, 8000);
      }

      if (await this.hasChanges(repoRoot)) await this.git(["add", "-A"], repoRoot);
      if (await this.hasStagedChanges(repoRoot)) {
        const message = `${this.settings.commitMessagePrefix}: ${this.formatTimestamp(new Date())}`;
        await this.git(["commit", "-m", message], repoRoot);
      }
      await this.git(["push"], repoRoot);
      this.notice("Git sync completed.", 5000);
    } catch (error: any) {
      console.error(error);
      this.notice(`Git sync failed: ${error.message ?? error}`, 12000);
    } finally {
      if (lockHandle) await this.releaseLock(lockHandle, lockPath);
      this.isRunning = false;
    }
  }

  private async showStatus() {
    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) { this.notice("Repository root not found.", 8000); return; }
    try {
      const result = await this.git(["status", "--short", "--branch"], repoRoot);
      const output = (result.stdout + result.stderr).trim();
      console.log(output);
      this.notice(output || "Repository is clean.", 10000);
    } catch (error: any) { this.notice(`Status failed: ${error.message ?? error}`, 10000); }
  }

  private async scanLargeFilesCommand() {
    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) { this.notice("Repository root not found.", 8000); return; }
    try {
      const result = await this.scanLargeFiles(repoRoot);
      console.table([...result.blocked, ...result.warned]);
      this.notice(`Large-file scan: ${result.blocked.length} blocked, ${result.warned.length} warned. See developer console for details.`, 10000);
    } catch (error: any) { this.notice(`Large-file scan failed: ${error.message ?? error}`, 10000); }
  }

  private async showConflictStatus() {
    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) { this.notice("Repository root not found.", 8000); return; }
    const conflicts = await this.getConflictFiles(repoRoot);
    if (conflicts.length === 0) { this.notice("No conflicted files detected.", 6000); return; }
    console.warn("Conflicted files:", conflicts);
    this.notice(`Conflicted files: ${conflicts.length}. See developer console.`, 10000);
  }

  private async abortRebaseOrMerge() {
    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) { this.notice("Repository root not found.", 8000); return; }
    const state = await this.getBusyGitState(repoRoot);
    if (!state) { this.notice("No rebase or merge state detected.", 6000); return; }
    try {
      if (state === "rebase") await this.git(["rebase", "--abort"], repoRoot);
      else if (state === "merge") await this.git(["merge", "--abort"], repoRoot);
      else if (state === "cherry-pick") await this.git(["cherry-pick", "--abort"], repoRoot);
      this.notice(`${state} aborted.`, 8000);
    } catch (error: any) { this.notice(`Abort failed: ${error.message ?? error}`, 12000); }
  }

  private async reportConflictAfterFailedPull(repoRoot: string, backupDir: string | null, error: any) {
    const conflicts = await this.getConflictFiles(repoRoot);
    const state = await this.getBusyGitState(repoRoot);
    if (conflicts.length > 0 || state) {
      console.warn("Git pull/rebase conflict.", { state, conflicts, backupDir, error: error?.message ?? error });
      const backupText = backupDir ? ` Local backup: ${backupDir}` : "";
      this.notice(`Sync stopped: Git conflict detected.${backupText} Use conflict status or abort command.`, 15000);
      return;
    }
    throw error;
  }

  private async resolveRepoRoot(): Promise<string | null> {
    if (this.settings.repoRoot.trim()) {
      const configured = path.resolve(this.settings.repoRoot.trim());
      if (await this.pathExists(path.join(configured, ".git"))) return configured;
      return null;
    }
    const vaultPath = this.getVaultPath();
    if (!vaultPath) return null;
    let current = vaultPath;
    while (true) {
      if (await this.pathExists(path.join(current, ".git"))) return current;
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
    return null;
  }

  private getVaultPath(): string | null {
    const adapter: any = this.app.vault.adapter;
    if (typeof adapter.getBasePath === "function") return adapter.getBasePath();
    return null;
  }

  private async ensureGitRepo(repoRoot: string) { await this.git(["rev-parse", "--is-inside-work-tree"], repoRoot); }
  private async hasChanges(repoRoot: string): Promise<boolean> { const r = await this.git(["status", "--porcelain"], repoRoot); return r.stdout.trim().length > 0; }
  private async hasStagedChanges(repoRoot: string): Promise<boolean> { try { await this.git(["diff", "--cached", "--quiet"], repoRoot); return false; } catch { return true; } }

  private async getBusyGitState(repoRoot: string): Promise<"rebase" | "merge" | "cherry-pick" | null> {
    const raw = (await this.git(["rev-parse", "--git-dir"], repoRoot)).stdout.trim();
    const gitDir = path.isAbsolute(raw) ? raw : path.join(repoRoot, raw);
    if (await this.pathExists(path.join(gitDir, "rebase-merge")) || await this.pathExists(path.join(gitDir, "rebase-apply"))) return "rebase";
    if (await this.pathExists(path.join(gitDir, "MERGE_HEAD"))) return "merge";
    if (await this.pathExists(path.join(gitDir, "CHERRY_PICK_HEAD"))) return "cherry-pick";
    return null;
  }

  private async getConflictFiles(repoRoot: string): Promise<string[]> {
    const r = await this.git(["diff", "--name-only", "--diff-filter=U"], repoRoot);
    return r.stdout.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  }

  private async backupLocalChanges(repoRoot: string): Promise<string | null> {
    const files = await this.getLocallyChangedFiles(repoRoot);
    if (files.length === 0) return null;
    const stamp = this.formatTimestampForPath(new Date());
    const backupDir = path.join(repoRoot, this.settings.conflictBackupDir || ".obsidian-git-conflicts", stamp);
    await fsp.mkdir(backupDir, { recursive: true });
    let count = 0;
    for (const rel of files) {
      const abs = path.join(repoRoot, rel);
      if (!(await this.pathExists(abs))) continue;
      const stat = await fsp.stat(abs);
      if (!stat.isFile()) continue;
      const dest = path.join(backupDir, rel);
      await fsp.mkdir(path.dirname(dest), { recursive: true });
      await fsp.copyFile(abs, dest);
      count += 1;
    }
    if (count === 0) return null;
    await fsp.writeFile(path.join(backupDir, "_backup-info.txt"), [`created=${new Date().toISOString()}`, `host=${os.hostname()}`, `repo=${repoRoot}`, `files=${count}`].join("\n"), "utf8");
    return path.relative(repoRoot, backupDir);
  }

  private async getLocallyChangedFiles(repoRoot: string): Promise<string[]> {
    const r = await this.git(["status", "--porcelain", "-z"], repoRoot);
    const entries = r.stdout.split("\0").filter(Boolean);
    const files: string[] = [];
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (entry.length < 4) continue;
      const status = entry.slice(0, 2);
      let file = entry.slice(3);
      if (status.includes("R") || status.includes("C")) { i += 1; if (i < entries.length) file = entries[i]; }
      if (file && !file.startsWith(this.settings.conflictBackupDir + "/")) files.push(file);
    }
    return Array.from(new Set(files));
  }

  private async scanLargeFiles(repoRoot: string): Promise<{ blocked: FileSizeRecord[]; warned: FileSizeRecord[] }> {
    const r = await this.git(["ls-files", "--cached", "--others", "--modified", "--exclude-standard", "-z"], repoRoot);
    const files = r.stdout.split("\0").filter(Boolean);
    const blocked: FileSizeRecord[] = [], warned: FileSizeRecord[] = [];
    const warnBytes = Math.max(0, this.settings.warnLargeFileMB) * 1024 * 1024;
    const blockBytes = Math.max(0, this.settings.blockLargeFileMB) * 1024 * 1024;
    for (const rel of files) {
      if (!rel || rel.startsWith(".git/")) continue;
      const abs = path.join(repoRoot, rel);
      if (!(await this.pathExists(abs))) continue;
      const stat = await fsp.stat(abs);
      if (!stat.isFile()) continue;
      const rec = { file: rel, mb: Math.round((stat.size / 1024 / 1024) * 100) / 100 };
      if (blockBytes > 0 && stat.size > blockBytes) blocked.push(rec);
      else if (warnBytes > 0 && stat.size > warnBytes) warned.push(rec);
    }
    return { blocked, warned };
  }

  private git(args: string[], cwd: string): Promise<GitResult> {
    return new Promise((resolve, reject) => {
      execFile(this.settings.gitPath || "git", args, { cwd, windowsHide: true, timeout: 5 * 60 * 1000, maxBuffer: 50 * 1024 * 1024, env: { ...process.env, GIT_TERMINAL_PROMPT: "0" } }, (error, stdout, stderr) => {
        if (error) { const detail = [stderr, stdout].filter(Boolean).join("\n").trim(); reject(new Error(detail || error.message)); return; }
        resolve({ stdout, stderr });
      });
    });
  }

  private async acquireLock(lockPath: string, reason: string): Promise<fs.promises.FileHandle | null> {
    try {
      const handle = await fsp.open(lockPath, "wx");
      await handle.writeFile([`pid=${process.pid}`, `host=${os.hostname()}`, `reason=${reason}`, `created=${new Date().toISOString()}`].join("\n"), "utf8");
      return handle;
    } catch (error: any) { if (error?.code === "EEXIST") return null; throw error; }
  }
  private async releaseLock(handle: fs.promises.FileHandle, lockPath: string) { try { await handle.close(); } catch {} try { await fsp.unlink(lockPath); } catch {} }
  private async cleanupStaleLock(lockPath: string) {
    if (!(await this.pathExists(lockPath))) return;
    const stat = await fsp.stat(lockPath);
    const staleMs = this.settings.lockStaleMinutes * 60 * 1000;
    if (this.settings.lockStaleMinutes > 0 && Date.now() - stat.mtimeMs > staleMs) { await fsp.unlink(lockPath); this.notice("Removed stale Git sync lock.", 5000); }
  }
  private async pathExists(target: string): Promise<boolean> { try { await fsp.access(target); return true; } catch { return false; } }
  private formatTimestamp(d: Date): string { const p = (n:number)=>String(n).padStart(2,"0"); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; }
  private formatTimestampForPath(d: Date): string { const p = (n:number)=>String(n).padStart(2,"0"); return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`; }
}

class MultiVaultGitSyncSettingTab extends PluginSettingTab {
  plugin: MultiVaultGitSyncPlugin;
  constructor(app: App, plugin: MultiVaultGitSyncPlugin) { super(app, plugin); this.plugin = plugin; }
  display(): void {
    const { containerEl } = this; containerEl.empty(); containerEl.createEl("h2", { text: "MultiVault Git Sync" });
    new Setting(containerEl).setName("Repository root").setDesc("Absolute path to the folder containing .git. Leave empty to auto-detect upward from current vault.").addText(t=>t.setPlaceholder("F:\\Obsidian library").setValue(this.plugin.settings.repoRoot).onChange(async v=>{ this.plugin.settings.repoRoot=v.trim(); await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Git executable").setDesc("Use git if Git is already in PATH. Otherwise use full git.exe path.").addText(t=>t.setPlaceholder("git").setValue(this.plugin.settings.gitPath).onChange(async v=>{ this.plugin.settings.gitPath=v.trim()||"git"; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Auto sync interval").setDesc("Minutes between automatic syncs. Set 0 to disable. Restart Obsidian after changing this value.").addText(t=>t.setPlaceholder("0").setValue(String(this.plugin.settings.autoSyncIntervalMinutes)).onChange(async v=>{ const n=Number(v); this.plugin.settings.autoSyncIntervalMinutes=Number.isFinite(n)&&n>=0?n:0; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Sync on startup").setDesc("Run one sync shortly after Obsidian starts.").addToggle(t=>t.setValue(this.plugin.settings.syncOnStartup).onChange(async v=>{ this.plugin.settings.syncOnStartup=v; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Back up local changes before pull").setDesc("Copy locally changed files before pulling remote changes.").addToggle(t=>t.setValue(this.plugin.settings.backupLocalChangesBeforePull).onChange(async v=>{ this.plugin.settings.backupLocalChangesBeforePull=v; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Conflict backup directory").setDesc("Relative path under repository root.").addText(t=>t.setPlaceholder(".obsidian-git-conflicts").setValue(this.plugin.settings.conflictBackupDir).onChange(async v=>{ this.plugin.settings.conflictBackupDir=v.trim()||".obsidian-git-conflicts"; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Large-file warning threshold MB").setDesc("Files above this size produce warnings.").addText(t=>t.setPlaceholder("50").setValue(String(this.plugin.settings.warnLargeFileMB)).onChange(async v=>{ const n=Number(v); this.plugin.settings.warnLargeFileMB=Number.isFinite(n)&&n>=0?n:50; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Large-file blocking threshold MB").setDesc("Files above this size stop sync before commit.").addText(t=>t.setPlaceholder("100").setValue(String(this.plugin.settings.blockLargeFileMB)).onChange(async v=>{ const n=Number(v); this.plugin.settings.blockLargeFileMB=Number.isFinite(n)&&n>=0?n:100; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Commit message prefix").setDesc("The plugin appends a timestamp.").addText(t=>t.setPlaceholder("obsidian sync").setValue(this.plugin.settings.commitMessagePrefix).onChange(async v=>{ this.plugin.settings.commitMessagePrefix=v.trim()||"obsidian sync"; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Stale lock timeout").setDesc("Minutes after which an abandoned lock file is removed. Use 0 to disable.").addText(t=>t.setPlaceholder("30").setValue(String(this.plugin.settings.lockStaleMinutes)).onChange(async v=>{ const n=Number(v); this.plugin.settings.lockStaleMinutes=Number.isFinite(n)&&n>=0?n:30; await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Show notices").setDesc("Show Obsidian notifications for sync status.").addToggle(t=>t.setValue(this.plugin.settings.showNotices).onChange(async v=>{ this.plugin.settings.showNotices=v; await this.plugin.saveSettings(); }));
  }
}
