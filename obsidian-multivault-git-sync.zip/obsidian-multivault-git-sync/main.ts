import {
  App,
  Notice,
  Plugin,
  PluginSettingTab,
  Setting
} from "obsidian";

import { execFile } from "child_process";
import * as fs from "fs";
import * as fsp from "fs/promises";
import * as path from "path";
import * as os from "os";

interface MultiVaultGitSyncSettings {
  repoRoot: string;
  gitPath: string;
  autoSyncIntervalMinutes: number;
  syncOnStartup: boolean;
  commitMessagePrefix: string;
  lockStaleMinutes: number;
  showNotices: boolean;
}

const DEFAULT_SETTINGS: MultiVaultGitSyncSettings = {
  repoRoot: "",
  gitPath: "git",
  autoSyncIntervalMinutes: 0,
  syncOnStartup: false,
  commitMessagePrefix: "obsidian sync",
  lockStaleMinutes: 30,
  showNotices: true
};

type GitResult = {
  stdout: string;
  stderr: string;
};

export default class MultiVaultGitSyncPlugin extends Plugin {
  settings: MultiVaultGitSyncSettings;
  private queue: Promise<void> = Promise.resolve();
  private isRunning = false;

  async onload() {
    await this.loadSettings();
    this.addSettingTab(new MultiVaultGitSyncSettingTab(this.app, this));

    this.addCommand({
      id: "sync-repository-now",
      name: "Sync repository now",
      callback: () => this.enqueueSync("manual")
    });

    this.addCommand({
      id: "show-repository-status",
      name: "Show repository status",
      callback: () => this.showStatus()
    });

    if (this.settings.syncOnStartup) {
      window.setTimeout(() => this.enqueueSync("startup"), 3000);
    }

    if (this.settings.autoSyncIntervalMinutes > 0) {
      const ms = this.settings.autoSyncIntervalMinutes * 60 * 1000;
      this.registerInterval(
        window.setInterval(() => this.enqueueSync("interval"), ms)
      );
    }
  }

  onunload() {}

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  private notice(message: string, timeout = 5000) {
    if (this.settings.showNotices) {
      new Notice(message, timeout);
    }
    console.log(`[MultiVault Git Sync] ${message}`);
  }

  private enqueueSync(reason: string) {
    this.queue = this.queue
      .then(() => this.syncRepository(reason))
      .catch((error) => {
        console.error(error);
        this.notice(`Git sync failed: ${error.message ?? error}`, 10000);
      });
  }

  private async showStatus() {
    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) {
      this.notice("Repository root not found. Configure it in plugin settings.", 8000);
      return;
    }

    try {
      const result = await this.git(["status", "--short", "--branch"], repoRoot);
      const output = (result.stdout + result.stderr).trim();
      console.log(output);
      this.notice(output || "Repository is clean.", 10000);
    } catch (error: any) {
      this.notice(`Status failed: ${error.message ?? error}`, 10000);
    }
  }

  private async syncRepository(reason: string) {
    if (this.isRunning) {
      this.notice("Sync skipped: another sync is already running.", 5000);
      return;
    }

    this.isRunning = true;

    const repoRoot = await this.resolveRepoRoot();
    if (!repoRoot) {
      this.isRunning = false;
      this.notice("Repository root not found. Configure it in plugin settings.", 8000);
      return;
    }

    const gitDir = path.join(repoRoot, ".git");
    const lockPath = path.join(gitDir, "obsidian-multivault-sync.lock");

    let lockHandle: fs.promises.FileHandle | null = null;

    try {
      await this.ensureGitRepo(repoRoot);
      await this.cleanupStaleLock(lockPath);
      lockHandle = await this.acquireLock(lockPath, reason);

      if (!lockHandle) {
        this.notice("Sync skipped: another vault is syncing this repository.", 5000);
        return;
      }

      this.notice(`Git sync started (${reason}).`, 4000);

      await this.git(["pull", "--rebase", "--autostash"], repoRoot);

      const hasChangesBeforeAdd = await this.hasChanges(repoRoot);
      if (hasChangesBeforeAdd) {
        await this.git(["add", "-A"], repoRoot);
      }

      const staged = await this.hasStagedChanges(repoRoot);
      if (staged) {
        const message = `${this.settings.commitMessagePrefix}: ${this.formatTimestamp(new Date())}`;
        await this.git(["commit", "-m", message], repoRoot);
      }

      await this.git(["push"], repoRoot);

      this.notice("Git sync completed.", 5000);
    } catch (error: any) {
      console.error(error);
      this.notice(`Git sync failed: ${error.message ?? error}`, 12000);
    } finally {
      if (lockHandle) {
        await this.releaseLock(lockHandle, lockPath);
      }
      this.isRunning = false;
    }
  }

  private async resolveRepoRoot(): Promise<string | null> {
    if (this.settings.repoRoot.trim()) {
      const configured = path.resolve(this.settings.repoRoot.trim());
      if (await this.pathExists(path.join(configured, ".git"))) {
        return configured;
      }
      return null;
    }

    const vaultPath = this.getVaultPath();
    if (!vaultPath) return null;

    let current = vaultPath;
    while (true) {
      if (await this.pathExists(path.join(current, ".git"))) {
        return current;
      }
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
    return null;
  }

  private getVaultPath(): string | null {
    const adapter: any = this.app.vault.adapter;
    if (typeof adapter.getBasePath === "function") {
      return adapter.getBasePath();
    }
    return null;
  }

  private async ensureGitRepo(repoRoot: string) {
    await this.git(["rev-parse", "--is-inside-work-tree"], repoRoot);
  }

  private async hasChanges(repoRoot: string): Promise<boolean> {
    const result = await this.git(["status", "--porcelain"], repoRoot);
    return result.stdout.trim().length > 0;
  }

  private async hasStagedChanges(repoRoot: string): Promise<boolean> {
    try {
      await this.git(["diff", "--cached", "--quiet"], repoRoot);
      return false;
    } catch {
      return true;
    }
  }

  private git(args: string[], cwd: string): Promise<GitResult> {
    return new Promise((resolve, reject) => {
      execFile(
        this.settings.gitPath || "git",
        args,
        {
          cwd,
          windowsHide: true,
          timeout: 5 * 60 * 1000,
          maxBuffer: 20 * 1024 * 1024,
          env: {
            ...process.env,
            GIT_TERMINAL_PROMPT: "0"
          }
        },
        (error, stdout, stderr) => {
          if (error) {
            const detail = [stderr, stdout].filter(Boolean).join("\n").trim();
            reject(new Error(detail || error.message));
            return;
          }
          resolve({ stdout, stderr });
        }
      );
    });
  }

  private async acquireLock(lockPath: string, reason: string): Promise<fs.promises.FileHandle | null> {
    try {
      const handle = await fsp.open(lockPath, "wx");
      const content = [
        `pid=${process.pid}`,
        `host=${os.hostname()}`,
        `reason=${reason}`,
        `created=${new Date().toISOString()}`
      ].join("\n");
      await handle.writeFile(content, "utf8");
      return handle;
    } catch (error: any) {
      if (error?.code === "EEXIST") return null;
      throw error;
    }
  }

  private async releaseLock(handle: fs.promises.FileHandle, lockPath: string) {
    try {
      await handle.close();
    } catch {}
    try {
      await fsp.unlink(lockPath);
    } catch {}
  }

  private async cleanupStaleLock(lockPath: string) {
    if (!(await this.pathExists(lockPath))) return;

    const stat = await fsp.stat(lockPath);
    const ageMs = Date.now() - stat.mtimeMs;
    const staleMs = this.settings.lockStaleMinutes * 60 * 1000;

    if (this.settings.lockStaleMinutes > 0 && ageMs > staleMs) {
      await fsp.unlink(lockPath);
      this.notice("Removed stale Git sync lock.", 5000);
    }
  }

  private async pathExists(target: string): Promise<boolean> {
    try {
      await fsp.access(target);
      return true;
    } catch {
      return false;
    }
  }

  private formatTimestamp(date: Date): string {
    const pad = (n: number) => String(n).padStart(2, "0");
    return [
      date.getFullYear(),
      "-",
      pad(date.getMonth() + 1),
      "-",
      pad(date.getDate()),
      " ",
      pad(date.getHours()),
      ":",
      pad(date.getMinutes()),
      ":",
      pad(date.getSeconds())
    ].join("");
  }
}

class MultiVaultGitSyncSettingTab extends PluginSettingTab {
  plugin: MultiVaultGitSyncPlugin;

  constructor(app: App, plugin: MultiVaultGitSyncPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("h2", { text: "MultiVault Git Sync" });

    new Setting(containerEl)
      .setName("Repository root")
      .setDesc("Absolute path to the folder containing .git. Leave empty to auto-detect by walking upward from the current vault.")
      .addText(text => text
        .setPlaceholder("D:\\obsidian-sync")
        .setValue(this.plugin.settings.repoRoot)
        .onChange(async (value) => {
          this.plugin.settings.repoRoot = value.trim();
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("Git executable")
      .setDesc("Use 'git' if Git is already in PATH. Otherwise set the full path to git.exe.")
      .addText(text => text
        .setPlaceholder("git")
        .setValue(this.plugin.settings.gitPath)
        .onChange(async (value) => {
          this.plugin.settings.gitPath = value.trim() || "git";
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("Auto sync interval")
      .setDesc("Minutes between automatic syncs. Set 0 to disable. Restart Obsidian after changing this value.")
      .addText(text => text
        .setPlaceholder("0")
        .setValue(String(this.plugin.settings.autoSyncIntervalMinutes))
        .onChange(async (value) => {
          const parsed = Number(value);
          this.plugin.settings.autoSyncIntervalMinutes = Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("Sync on startup")
      .setDesc("Run a sync shortly after Obsidian starts.")
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.syncOnStartup)
        .onChange(async (value) => {
          this.plugin.settings.syncOnStartup = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("Commit message prefix")
      .setDesc("The plugin appends a timestamp to this prefix.")
      .addText(text => text
        .setPlaceholder("obsidian sync")
        .setValue(this.plugin.settings.commitMessagePrefix)
        .onChange(async (value) => {
          this.plugin.settings.commitMessagePrefix = value.trim() || "obsidian sync";
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("Stale lock timeout")
      .setDesc("Minutes after which an abandoned lock file is removed. Use 0 to disable stale lock cleanup.")
      .addText(text => text
        .setPlaceholder("30")
        .setValue(String(this.plugin.settings.lockStaleMinutes))
        .onChange(async (value) => {
          const parsed = Number(value);
          this.plugin.settings.lockStaleMinutes = Number.isFinite(parsed) && parsed >= 0 ? parsed : 30;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("Show notices")
      .setDesc("Show Obsidian notifications for sync status.")
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.showNotices)
        .onChange(async (value) => {
          this.plugin.settings.showNotices = value;
          await this.plugin.saveSettings();
        }));
  }
}