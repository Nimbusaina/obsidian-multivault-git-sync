# MultiVault Git Sync

Desktop-only Obsidian plugin for this repository layout:

```text
obsidian-sync/
├── Vault-A/
├── Vault-B/
├── Vault-C/
└── .git/
```

The plugin is designed to reduce instability when several Obsidian vaults share one Git repository. It uses a cross-vault lock file and runs Git operations serially:

```text
git pull --rebase --autostash
git add -A
git commit -m "obsidian sync: YYYY-MM-DD HH:mm:ss"   # skipped if no changes
git push
```

## Safety model

- Only one Git task runs at a time across all vaults using this plugin.
- Lock file is stored in `.git/obsidian-multivault-sync.lock`.
- Stale lock cleanup is supported.
- Sync is skipped if another sync is active.
- Plugin is desktop-only because it uses Node.js `child_process`.

## Recommended usage

In a one-repo-many-vault setup, enable automatic sync in only one vault.

You may install the plugin in several vaults for manual sync, but avoid enabling automatic sync in all of them unless you accept frequent skipped jobs due to locking.

## Install for testing

1. Build:

```bash
npm install
npm run build
```

2. Copy these files into one vault:

```text
Vault-A/.obsidian/plugins/multivault-git-sync/
├── main.js
└── manifest.json
```

3. Enable the plugin in Obsidian.

## Settings

- Repository root: absolute path to the folder containing `.git`.
- Auto sync interval: minutes between sync runs. Set `0` to disable.
- Sync on startup: run one sync after Obsidian starts.
- Commit message prefix: prefix for generated commit messages.
- Git executable: usually `git`.